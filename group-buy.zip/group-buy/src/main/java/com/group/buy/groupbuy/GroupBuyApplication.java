package com.group.buy.groupbuy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroupBuyApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroupBuyApplication.class, args);
	}
}
